Thomas Jefferson
==================

* Honesty is the first chapter in the book of wisdom 
* Never spend money before you have earned it 
